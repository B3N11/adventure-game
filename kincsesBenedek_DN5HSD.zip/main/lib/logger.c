#include "logger.h"

void ExitError(const char* msg){

  printf("%s", msg);
  exit(1);
}
